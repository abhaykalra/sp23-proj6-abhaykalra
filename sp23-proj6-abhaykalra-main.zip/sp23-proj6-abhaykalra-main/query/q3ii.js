// Task 3ii

db.credits.aggregate([
    // TODO: Write your query here
    {$unwind: "$cast"},
        {$unwind: "$crew"},
        {$project:
            {
                job: "$crew.job",
                crewId: "$crew.id",
                cast: 1
            }
        },
        {$match: {
            crewId: 5655,
            job: "Director"
            }
        },
        {
            $group: {
                _id: {val1: "$cast.name", val2: "$cast.id"},
                count: {$sum: 1}
            }
        },
        {
            $project: {
                id: "$_id.val2",
                name: "$_id.val1",
                _id: 0,
                count: 1
            }
        },
        {$sort: {count: -1, id: 1}},
        {$limit: 5}
]);