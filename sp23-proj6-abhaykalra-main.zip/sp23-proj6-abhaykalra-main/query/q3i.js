// Task 3i

db.credits.aggregate([
    // TODO: Write your query here
    {$match:
            {cast:
                {$elemMatch:
                    {id: 7624}
                }
            }
        },
        {$unwind: "$cast"},
        {
            $lookup: {
                from: "movies_metadata",
                localField: "movieId",
                foreignField: "movieId",
                as: "movies"
            }
        },
        {
            $project: {
                castIdentifier: "$cast.id",
                title: {$first: "$movies.title"},
                character: "$cast.character",
                release_date: {$first: "$movies.release_date"},

            }
        },
        {
            $match: {
                castIdentifier: 7624
            }
        },
        {
            $project: {
            title: 1,
            release_date: 1,
            character: 1,
            _id: 0,
            }
        },
        {
            $sort: {
                release_date: -1
            }
        }
]);