// Task 2ii

db.movies_metadata.aggregate([
    // TODO: Write your query here
    {
            $project: {
                _id: 0,
                words: {
                $split: [{
                    $toLower: "$tagline"},
                    " "]
                }
            }
        },
        {
            $unwind: "$words"
        },
        {
            $project: {
                _id: 0,
                words: 1,
                length: {
                $strLenCP: "$words"
                }
            }
        },
        {$match:
            {length:
                {$gt: 3}
            }
        },
        {$project:
            {words:
                {$trim:
                    {input: "$words", chars: "!.,?"}
                }
            }
        },
        {$group: {
            _id: "$words",
            count: {$sum: 1}
            }
        },
        {$sort: {count: -1}},
        {$limit: 20}
]);