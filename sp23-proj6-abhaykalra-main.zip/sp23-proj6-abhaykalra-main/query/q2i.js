// Task 2i

db.movies_metadata.aggregate([
    // TODO: Write your query here
    {
            $project: {
              _id: 0,
              title: 1,
              vote_count: 1,
              score: {
                $round: [{
                  $add: [
                    {$multiply: [{
                        $divide: [1838,
                        {$add: [1838, "$vote_count"]}
                        ]},
                    7]},
                    {$multiply: [{
                    $divide: ["$vote_count",
                    {$add: [1838, "$vote_count"]}]},
                    "$vote_average"]}
                  ]},
              2]},
            }
          },
          {$sort: {score: -1, vote_count: -1, title: 1}},
          {$limit: 20},
]);